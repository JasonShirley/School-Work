import javax.swing.*;
import java.sql.*;


public class Connector {
    private static String hostname = "csdb.cs.eou.edu";
    private static String port = "3306";
    private static String database = "dbShirleyTrack";
    private static String user = "jshirley";
    private static String password = "Ar97306!@";
    private static String flags = "?noAccessToProcedureBodies=true";


    public Connector() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
    }

    public void addAthlete(String athleteFirstName, String athleteLastName, String athleteGender, String athleteSchool) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);
            String query = " insert into Athletes (firstName, lastName, gender, school)"
                    + " values (?, ?, ?, ?)";
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setString(1, athleteFirstName);
            preparedStmt.setString(2, athleteLastName);
            preparedStmt.setString(3, athleteGender);
            preparedStmt.setString(4, athleteSchool);
            preparedStmt.execute();
            conn.close();
        }
        catch(SQLException ex){
            System.err.println("there was an error accessing the database");
            String errorMsg = "JShirleyTrackDB: Insert Error. ReEnter Data";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Insert Error. ReEnter Data", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void enterNewResult (int eventId, int competitorNumber, String qualified, float mark){
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);
            String query = " insert into EventResult (eventId, competitorNumber, qualified, mark)"
                    + " values (?, ?, ?, ?)";
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(1, eventId);
            preparedStmt.setInt(2, competitorNumber);
            preparedStmt.setString(3, qualified);
            preparedStmt.setFloat(4, mark);
            preparedStmt.execute();
            conn.close();
        }
        catch(SQLException ex){
            System.err.println("there was an error accessing the database");
        }
    }

    public void getResult (int eventId){
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);
            Statement stmt = conn.createStatement();

            boolean gotResults = stmt.execute("select e.eventId, a.firstName, a.lastName, e.eventName, e.gender, er.mark, s.schoolName, er.qualified, er.points" +
                    ", er.competitorPlacement from Event as e, EventResult as er, Athletes as a, School as s " +
                    "where a.competitorNumber = er.competitorNumber and er.eventId = e.eventId and a.school = s.schoolId and " +
                    "e.eventId = " + eventId + " order by points desc");
            ResultSet rs = stmt.getResultSet();
            rs.first();
            System.out.format("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s", "Place", "First Name", "Last Name","EventID", "Event", "Result", "Points", "School", "Qualified");
            System.out.println();
            while (gotResults) {
                String school = rs.getString("schoolName");
                String eventName = rs.getString("eventName");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String qualified = rs.getString("qualified");
                int points = rs.getInt("points");
                int place = rs.getInt("competitorPlacement");
                float mark = rs.getFloat("mark");
                System.out.format("%-25d%-25s%-25s%-25d%-25s%-25f%-25d%-25s%-25s", place, firstName, lastName, eventId, eventName, mark, points, school, qualified);
                System.out.println();
                gotResults = rs.next();
            }
            System.out.println("\n\n");
            conn.close();
        }
        catch (SQLException ex) {
            System.err.println("there was an error accessing the database");
            System.err.println("there was an error accessing the database");
            String errorMsg = "JShirleyTrackDB: Query Error. ReEnter Data to Query";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Query Error. ReEnter Data to Query", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void scoreEvent(int eventId){
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);
            Statement stmt = conn.createStatement();

            PreparedStatement preparedStmt = conn.prepareStatement("select * from Event where eventId = " + eventId);
            ResultSet rs = preparedStmt.executeQuery();
            rs.first();
            String isTrackEvent = rs.getString("trackEvent");
            String isFieldEvent = rs.getString("fieldEvent");
            if (isTrackEvent.equals("TRUE")) {
                CallableStatement cStmnt = conn.prepareCall("{call scoreTrackEvent(?)}");
                cStmnt.setInt(1, eventId);
                cStmnt.execute();
                conn.close();
            }
            else if (isFieldEvent.equals("TRUE")){
                CallableStatement cStmnt = conn.prepareCall("{call scoreFieldEvent(?)}");
                cStmnt.setInt(1, eventId);
                cStmnt.execute();
                conn.close();
            }
        }
        catch (SQLException ex) {
            System.err.println("there was an error accessing the database");
            String errorMsg = "JShirleyTrackDB: Query Error. ReEnter Data to Query";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Query Error. ReEnter Data to Query", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void disqualifySingle (int eventId, int athleteId){
        try {


            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);

            PreparedStatement preparedStmnt = conn.prepareStatement("select competitorNumber from Athletes where competitorNumber = " + athleteId);
            ResultSet rs = preparedStmnt.executeQuery();
            // Cursor will only change the value of qualified to FALSE for an eventId passed in from outside of method
            if(rs.next()) {
                String query = "update EventResult set qualified = 'FALSE' where competitorNumber = ? and eventId = ?";
                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setInt(1, athleteId);
                preparedStmt.setInt(2, eventId);
                preparedStmt.execute();
                conn.close();
            }
            else{
                System.err.println("there was an error accessing the database");
                String errorMsg = "JShirleyTrackDB: Query Error. ReEnter Data ";
                JOptionPane.showMessageDialog(null, errorMsg,
                        "JShirleyTrackDB: Result Not Found. ReEnter Data ", JOptionPane.ERROR_MESSAGE);
            }

        }
        catch (SQLException ex){
            System.err.println("there was an error accessing the database");
            String errorMsg = "JShirleyTrackDB: Query Error. ReEnter ";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Data Not Found, ReEnter Data", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void disqualifyAll (int athleteId){
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);
            String query = "update EventResult set qualified = 'FALSE' where competitorNumber = ?";
            PreparedStatement preparedStmnt = conn.prepareStatement("select competitorNumber from Athletes where competitorNumber = " + athleteId);
            ResultSet rs = preparedStmnt.executeQuery();
            // Cursor iterates through all the records of an athlete
            if(rs.next()) {
                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setInt(1, athleteId);
                preparedStmt.execute();
                conn.close();
            }
            else{
                System.err.println("there was an error accessing the database");
                String errorMsg = "JShirleyTrackDB: Query Error. ReEnter Data ";
                JOptionPane.showMessageDialog(null, errorMsg,
                        "JShirleyTrackDB: Data Not Found, ReEnter Data ", JOptionPane.ERROR_MESSAGE);
            }

        }
        catch (SQLException ex){
            System.err.println("there was an error accessing the database");
            String errorMsg = "JShirleyTrackDB: Query Error. ReEnter Data to Query";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Query Error. ReEnter Data to Query", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void checkIfQualified (){
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);

            // checkQualified will check to see if any athlete competed in over 4 events, and if true will
            // mark all of their qualified status to FALSE
            CallableStatement cStmnt = conn.prepareCall("{call checkQualified()}");
            cStmnt.execute();
            conn.close();
            String msg = "JShirleyTrackDB: Any Athlete That Has Competed in \n Over 4 Events Has Been Disqualified";
            JOptionPane.showMessageDialog(null, msg,
                    "JShirleyTrackDB: Data Updated", JOptionPane.PLAIN_MESSAGE);
        }
        catch (SQLException ex) {
            System.err.println(ex);
            String errorMsg = "JShirleyTrackDB: Query Error";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Query Error. ReEnter Data to Query", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void countScores(){
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://"
                    + hostname + "/" + database + flags, user, password);

            int schoolId = 0;

            Statement stmt = conn.createStatement();
            boolean gotResults = stmt.execute("select schoolId from School");
            ResultSet rs = stmt.getResultSet();
            rs.first();

            PreparedStatement schoolStmt = conn.prepareStatement("select sum(points) from EventResult as e, Athletes as a, School as s " +
                    "                    where a.competitorNumber = e.competitorNumber " +
                    "                    AND a.school = s.schoolId and schoolId = ? and e.qualified = 'TRUE';");
            ResultSet rs2 = null;

            PreparedStatement scoreStmt = conn.prepareStatement("UPDATE School SET score = ? where schoolId = ?");

            // Score All The Schools For the Entire Meet
            while (gotResults){
                schoolId = rs.getInt("schoolId");
                schoolStmt.setInt(1,schoolId);
                rs2 = schoolStmt.executeQuery();
                if(rs2.next()) {
                    int score = rs2.getInt(1);
                    scoreStmt.setInt(1,score);
                    scoreStmt.setInt(2,schoolId);
                    scoreStmt.execute();
                }
                gotResults = rs.next();
            }

            // placeSchool callable statement will order schools and rank them according to the points that they scored
            CallableStatement cStmnt = conn.prepareCall("{call placeSchool()}");
            cStmnt.execute();
            gotResults = stmt.execute("select place, schoolName, score from School order by place asc");
            rs = stmt.getResultSet();
            rs.first();
            String school = null;
            int points = 0;
            int place = 0;
            System.out.format("%-25s%-25s%-25s", "Place", "School", "Points");
            System.out.println();
            while (gotResults) {
                points = rs.getInt("score");
                place = rs.getInt("place");
                school = rs.getString("schoolName");
                System.out.format("%-25d%-25s%-25d", place, school, points);
                System.out.println();
                gotResults = rs.next();
            }
            System.out.println("\n\n");

            //setMaleScore
            System.out.println("Men's Team Scores");
            PreparedStatement maleStmt = conn.prepareStatement("select sum(points) from EventResult as e, Athletes as a, School as s " +
                    " where a.competitorNumber = e.competitorNumber " +
                    " AND a.school = s.schoolId and schoolId = ? and e.qualified = 'TRUE' and a.gender = 'M';");
            rs2 = null;

            scoreStmt = conn.prepareStatement("UPDATE School SET scoreM = ? where schoolId = ?");
            gotResults = stmt.execute("select schoolId from School");
            rs = stmt.getResultSet();
            rs.first();
            System.out.println("HERE");
            while(gotResults){
                schoolId = rs.getInt("schoolId");
                maleStmt.setInt(1,schoolId);
                rs2 = maleStmt.executeQuery();
                if(rs2.next()) {
                    int score = rs2.getInt(1);
                    scoreStmt.setInt(1,score);
                    scoreStmt.setInt(2,schoolId);
                    scoreStmt.execute();
                }
                gotResults = rs.next();
            }
            cStmnt = conn.prepareCall("{call placeSchoolM()}");
            cStmnt.execute();
            gotResults = stmt.execute("select place, schoolName, scoreM from School order by place asc");
            rs = stmt.getResultSet();
            rs.first();
            school = null;
            points = 0;
            place = 0;
            System.out.format("%-25s%-25s%-25s", "Place", "School", "Points");
            System.out.println();
            while (gotResults) {
                points = rs.getInt("scoreM");
                place = rs.getInt("place");
                school = rs.getString("schoolName");
                System.out.format("%-25d%-25s%-25d", place, school, points);
                System.out.println();
                gotResults = rs.next();
            }
            System.out.println("\n\n");

            // Set femaleScore
            System.out.println("Women's Team Scores");
            PreparedStatement femaleStmt = conn.prepareStatement("select sum(points) from EventResult as e, Athletes as a, School as s " +
                    " where a.competitorNumber = e.competitorNumber " +
                    " AND a.school = s.schoolId and schoolId = ? and e.qualified = 'TRUE' and a.gender = 'F';");
            rs2 = null;

            scoreStmt = conn.prepareStatement("UPDATE School SET scoreF = ? where schoolId = ?");
            gotResults = stmt.execute("select schoolId from School");
            rs = stmt.getResultSet();
            rs.first();
            System.out.println("HERE");
            while(gotResults){
                schoolId = rs.getInt("schoolId");
                femaleStmt.setInt(1,schoolId);
                rs2 = femaleStmt.executeQuery();
                if(rs2.next()) {
                    int score = rs2.getInt(1);
                    scoreStmt.setInt(1,score);
                    scoreStmt.setInt(2,schoolId);
                    scoreStmt.execute();
                }
                gotResults = rs.next();
            }
            cStmnt = conn.prepareCall("{call placeSchoolF()}");
            cStmnt.execute();
            gotResults = stmt.execute("select place, schoolName, scoreF from School order by place asc");
            rs = stmt.getResultSet();
            rs.first();
            school = null;
            points = 0;
            place = 0;
            System.out.format("%-25s%-25s%-25s", "Place", "School", "Points");
            System.out.println();
            while (gotResults) {
                points = rs.getInt("scoreF");
                place = rs.getInt("place");
                school = rs.getString("schoolName");
                System.out.format("%-25d%-25s%-25d", place, school, points);
                System.out.println();
                gotResults = rs.next();
            }
            System.out.println("\n\n");

            conn.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
    }
}

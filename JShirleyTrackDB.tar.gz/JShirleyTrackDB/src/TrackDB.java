import java.sql.*;
import javax.swing.*;


/*
    TrackDB is used to query and update the track database that was assigned to me. It will use a simple GUI
    to allow for the user to navigate around the program.

 */
public class TrackDB {

    public static void main(String args[]) throws Exception {

        // Build the JOptionPane for selection of what to do
        JFrame frame = new JFrame("Input Dialog Example 3");
        String[] options = {"Add Athlete", "Enter New Result", "Get Results for an Event", "Score an Event"
                , "Disqualify an Athlete From One Event", "Disqualify an Athlete from the meet", "Score the Meet",
                "Check all Athletes Qualification", "Quit"};
        String choice = (String) JOptionPane.showInputDialog(frame,
                "Make A Selection",
                "JShirleyTrackDB",
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
        Connector connect = new Connector();
        try {
            while (choice != null && choice != "Quit") {
                if (choice.equals("Add Athlete")) {
                    String athleteFirstName = "";
                    String athleteLastName = "";
                    String athleteGender = "";
                    String athleteSchool = "";
                    JTextField athleteFName = new JTextField();
                    JTextField athleteLName = new JTextField();
                    JTextField athleteGen = new JTextField();
                    JTextField athleteSch = new JTextField();
                    Object[] message = {
                            "Enter Athlete's First Name:", athleteFName,
                            "Enter Athlete's Last Name", athleteLName,
                            "Enter Athlete's Gender ('M' or 'F')", athleteGen,
                            "Enter Athlete School id", athleteSch};
                    int continueFlag = JOptionPane.showConfirmDialog(null, message,
                            "JShirleyTrackDB: Add Athlete",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (continueFlag == JOptionPane.OK_OPTION) {
                        athleteFirstName = athleteFName.getText();
                        athleteLastName = athleteLName.getText();
                        athleteGender = athleteGen.getText().toUpperCase();
                        athleteSchool = athleteSch.getText();
                        if (!(athleteFirstName.equals("") || athleteLastName.equals("") || athleteGender.equals("")
                                || athleteSchool.equals(""))) {
                            connect.addAthlete(athleteFirstName, athleteLastName, athleteGender, athleteSchool);
                        } else {
                            String errorMsg = "Input Incorrect, Try Again: ";
                            JOptionPane.showMessageDialog(null, errorMsg,
                                    "JShirleyTrackDB: Blank Field Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }


                } else if (choice.equals("Enter New Result")) {
                    int eventId = -1;
                    int competitorNumber = -1;
                    String qualified;
                    float mark = -1;
                    JTextField event = new JTextField();
                    JTextField compNumber = new JTextField();
                    JTextField qualif = new JTextField();
                    JTextField marked = new JTextField();
                    Object[] message = {
                            "Enter Event Id", event,
                            "Enter Athlete's Competitor Number:", compNumber,
                            "Enter Athlete's Qualification ('TRUE', 'FALSE)", qualif,
                            "Enter Athlete's Mark", marked
                    };

                    int continueFlag = JOptionPane.showConfirmDialog(null, message,
                            "JShirleyTrackDB: Enter New Result",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (continueFlag == JOptionPane.OK_OPTION) {

                        if (!(eventId == -1 || competitorNumber == -1 || qualif == (null)
                                || mark == -1)) {
                            eventId = Integer.parseInt(event.getText());
                            competitorNumber = Integer.parseInt(compNumber.getText());
                            qualified = qualif.getText().toUpperCase();
                            mark = Float.parseFloat(marked.getText());
                            connect.enterNewResult(eventId, competitorNumber, qualified, mark);
                        } else {
                            String errorMsg = "Input Incorrect, Try Again: ";
                            JOptionPane.showMessageDialog(null, errorMsg,
                                    "JShirleyTrackDB: Blank Field Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }

                } else if (choice.equals("Get Results for an Event")) {
                    int eventId = -1;
                    String eventName = "";
                    JTextField event = new JTextField();
                    Object[] message = {
                            "Enter Event ID", event
                    };

                    int eventMessage = JOptionPane.showConfirmDialog(null, message,
                            "JShirleyTrackDB: Get Results for an Event",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (eventMessage == JOptionPane.OK_OPTION) {
                        eventId = Integer.parseInt(event.getText());

                        if (!(eventId == -1)) {
                            connect.getResult(eventId);
                        } else {
                            String errorMsg = "Input Incorrect, Try Again: ";
                            JOptionPane.showMessageDialog(null, errorMsg,
                                    "JShirleyTrackDB: Blank Field Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }

                }
                else if (choice.equals("Score an Event")) {
                    int eventId = -1;
                    JTextField event = new JTextField();
                    Object[] message = {
                            "Enter Event ID", event
                    };

                    int eventMessage = JOptionPane.showConfirmDialog(null, message,
                            "JShirleyTrackDB: Score an Event",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (eventMessage == JOptionPane.OK_OPTION) {
                        eventId = Integer.parseInt(event.getText());
                        if (!(eventId == -1)) {
                            connect.scoreEvent(eventId);
                        } else {
                            String errorMsg = "Input Incorrect, Try Again: ";
                            JOptionPane.showMessageDialog(null, errorMsg,
                                    "JShirleyTrackDB: Blank Field Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }

                }

                else if (choice.equals("Disqualify an Athlete From One Event")){
                    int eventId = -1;
                    int athleteId = -1;
                    JTextField event = new JTextField();
                    JTextField athlete = new JTextField();
                    Object[] message = {
                            "Enter Event ID", event,
                            "Enter Athlete ID", athlete,
                    };

                    int eventMessage = JOptionPane.showConfirmDialog(null, message,
                            "JShirleyTrackDB: Score an Event",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (eventMessage == JOptionPane.OK_OPTION) {
                        eventId = Integer.parseInt(event.getText());
                        athleteId = Integer.parseInt(athlete.getText());
                        if (!(eventId == -1 || athleteId == -1)) {
                            connect.disqualifySingle(eventId, athleteId);
                        } else {
                            String errorMsg = "Input Incorrect, Try Again: ";
                            JOptionPane.showMessageDialog(null, errorMsg,
                                    "JShirleyTrackDB: Blank Field Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }

                else if (choice.equals("Disqualify an Athlete from the meet")){
                    int athleteId = -1;
                    JTextField event = new JTextField();
                    JTextField athlete = new JTextField();
                    Object[] message = {
                            "Enter Athlete ID", athlete,
                    };

                    int eventMessage = JOptionPane.showConfirmDialog(null, message,
                            "JShirleyTrackDB: Score an Event",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (eventMessage == JOptionPane.OK_OPTION) {
                        athleteId = Integer.parseInt(athlete.getText());
                        if (!(athleteId== -1)) {
                            connect.disqualifyAll(athleteId);
                        } else {
                            String errorMsg = "Input Incorrect, Try Again: ";
                            JOptionPane.showMessageDialog(null, errorMsg,
                                    "JShirleyTrackDB: Blank Field Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }

                else if (choice.equals("Check all Athletes Qualification")){
                    connect.checkIfQualified();
                }
                else if (choice.equals("Score the Meet")){
                    connect.countScores();
                }
                choice = (String) JOptionPane.showInputDialog(frame,
                        "Make A Selection",
                        "JShirleyTrackDB",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]);
            }
            System.out.println("Exiting. Goodbye.");
            System.exit(0);
        }

        catch (NumberFormatException e){
            String errorMsg = "JShirleyTrackDB: Input Error, Input Proper Data in Fields." + "\n" + "Exiting Program";
            JOptionPane.showMessageDialog(null, errorMsg,
                    "JShirleyTrackDB: Input Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

}

